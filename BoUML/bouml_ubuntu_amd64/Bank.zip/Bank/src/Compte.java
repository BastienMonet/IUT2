
public class Compte {
  private float solde;

  private String numero;

  private float decouvertAutorise =  0;

  /**
   *  constructeur    
   */
  public Compte(String numero, float solde) {
        this.numero=numero;
        this.solde=solde;
  }

  /**
   *  getters/setters
   */
  public void setSolde(float val) {
        this.solde = val;
  }

  public float getSolde() {
        return this.solde;
  }

  public void setNumero(String num) {
        this.numero = num;
  }

  public String getNumero() {
        return this.numero;
  }

  public void setDecouvertAutorise(float val) {
        this.decouvertAutorise = val;
  }

  public float getDecouvertAutorise() {
        return this.decouvertAutorise;
  }

  /**
   *  opérations métiers
   */
  public boolean debiter(float montant, String info) {
        if(montant>0){
            float res = this.solde-montant;
            if(res>=this.decouvertAutorise){ // vérification solde après opératioin
                this.solde = res;
                return true;
            }
        }
        return false;
  }

  public boolean crediter(float montant, String info) {
        if(montant>0){
            this.solde += montant;
            return true;
        }
        return false;
  }

  public String toString() {
        return "je suis un compte bancaire";
  }

}
