import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Hopital {

    protected static List<Patient> patients = new ArrayList<>();

    protected static int taillAttente = 2;


    public Hopital() {
    }

    public void ajouteAttente() throws InterruptedException{}

    public void consulte() throws InterruptedException{}
    
    public Patient getPatient() {return null;}


    public static void setPatient(List<Patient> patients){
        Hopital.patients = patients;
    }

    public static void setTailleAttente(int taillAttente){
        Hopital.taillAttente = taillAttente;
    }

}