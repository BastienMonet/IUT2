import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import java.util.Random;
public class CentreTraumato extends Hopital {

    Lock verrouTraumaAttente = new ReentrantLock();

    Condition TraumaAttenteFull = verrouTraumaAttente.newCondition();
    Condition TraumaAttenteEmpty = verrouTraumaAttente.newCondition();

    private List<Patient> attenteTrauma;

    private Random rd;

    public CentreTraumato(){
        super();
        this.rd =  new Random();
        attenteTrauma = new ArrayList<>(taillAttente);
    }

    @Override
    public void ajouteAttente() throws InterruptedException{
        try {
            verrouTraumaAttente.lock();
            if (getPatient() == null){
                return;
            }
            while (attenteTrauma.size() == taillAttente){
                TraumaAttenteFull.await();
            }
            Thread.sleep(rd.nextInt(2000));
            System.out.println("patient ajouté");
            TraumaAttenteEmpty.signal();
            Patient patient =  getPatient();
            patients.remove(patient);
            attenteTrauma.add(patient);

        } finally {
            verrouTraumaAttente.unlock();
        }
    }

    @Override
    public void consulte() throws InterruptedException{
        try {
            verrouTraumaAttente.lock();
            if (getPatient() == null){
                return;
            }
            while (attenteTrauma.size() == 0){
                TraumaAttenteEmpty.await();
            }
            TraumaAttenteFull.signal();
            attenteTrauma.remove(getPatient());

        } finally {
            verrouTraumaAttente.unlock();
        }
    }


    @Override
    public Patient getPatient(){
        for (Patient p : patients){
            if (p.getPathologie() == Pathologie.TRAUMA){
                return p;
            }
        }
        return null;
    }



    
    

}
