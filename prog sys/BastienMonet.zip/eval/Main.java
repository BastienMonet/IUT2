public class Main {

    public static void main(String[] args) {
        Hopital hop = new Hopital();
        Hopital.setTailleAttente(4);
        CentreTraumato ct = new CentreTraumato();
        Infirmier infTraumato = new Infirmier(ct);
        Medecin medTraumato = new Medecin(ct);
        infTraumato.start();
        medTraumato.start();

    }
    
}
